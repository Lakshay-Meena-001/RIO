import MobileActionBar from "../../components/MobileActionBar";
import ServiceNavigation from "../../components/ServiceNavigation";
import TransactionStatusLabel from "../../components/billing/TransactionStatusLabel";
import BillingMetricCard from "../../components/billing/BillingMetricCard";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { motion, useReducedMotion } from "framer-motion";
import {
  FiArrowRight,
  FiArrowUpRight,
  FiCreditCard,
  FiClock,
  FiRefreshCw,
  FiAlertCircle,
  FiCheckCircle,
  FiPlus,
} from "react-icons/fi";

import Surface from "../../components/ui/Surface";

import {
  getBillingSummary,
  getBillingTransactions,
  createBillingOrder,
  verifyBillingPayment,
  getPendingBillingPayment,
  continueBillingPayment,
  cancelBillingPayment,
} from "../../api/billing/billing.api";

import AddBalanceModal from "./AddBalanceModal";
import PageEyebrow from "../../components/ui/PageEyebrow";

const ease = [0.22, 1, 0.36, 1];

const loadRazorpayScript = () =>
  new Promise((resolve) => {
    if (window.Razorpay) {
      resolve(true);
      return;
    }

    const existingScript = document.querySelector(
      'script[src="https://checkout.razorpay.com/v1/checkout.js"]',
    );

    if (existingScript) {
      existingScript.addEventListener("load", () => resolve(true), {
        once: true,
      });
      existingScript.addEventListener("error", () => resolve(false), {
        once: true,
      });
      return;
    }

    const script = document.createElement("script");
    script.src = "https://checkout.razorpay.com/v1/checkout.js";
    script.async = true;
    script.onload = () => resolve(true);
    script.onerror = () => resolve(false);
    document.body.appendChild(script);
  });

const unwrap = (value) => value?.data?.data ?? value?.data ?? value ?? {};

const getTransactionList = (response) => {
  const payload = unwrap(response);

  if (Array.isArray(payload)) return payload;
  if (Array.isArray(payload?.transactions)) return payload.transactions;
  if (Array.isArray(payload?.data)) return payload.data;
  if (Array.isArray(payload?.items)) return payload.items;

  return [];
};

const formatNumber = (value) => {
  const number = Number(value);

  return Number.isFinite(number)
    ? number.toLocaleString("en-IN", {
        maximumFractionDigits: 2,
      })
    : "—";
};

const formatCurrency = (value) => {
  const number = Number(value);

  return Number.isFinite(number)
    ? `₹${number.toLocaleString("en-IN", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      })}`
    : "—";
};

// Billing API stores transaction amounts in paise.
const formatInrFromPaise = (value) => {
  const amount = Number(value);

  return Number.isFinite(amount)
    ? (amount / 100).toLocaleString("en-IN", {
        style: "currency",
        currency: "INR",
        maximumFractionDigits: 2,
      })
    : "—";
};

const formatInrFromRupees = (value) => {
  const amount = Number(value);

  return Number.isFinite(amount)
    ? amount.toLocaleString("en-IN", {
        style: "currency",
        currency: "INR",
        maximumFractionDigits: 2,
      })
    : "—";
};

const formatDate = (value) => {
  if (!value) return "Date unavailable";

  const date = new Date(value);

  return Number.isNaN(date.getTime())
    ? "Date unavailable"
    : date.toLocaleDateString("en-IN", {
        day: "numeric",
        month: "short",
        year: "numeric",
      });
};

const getStatus = (transaction) =>
  String(
    transaction?.status ?? transaction?.paymentStatus ?? "unknown",
  ).toLowerCase();

const SUCCESS_STATUSES = new Set([
  "paid",
  "completed",
  "captured",
  "success",
  "succeeded",
]);

// Keep the last successful billing snapshot while the user navigates between
// dashboard pages. Explicit refreshes and payment actions still fetch fresh data.
const billingDashboardCacheByUser = new Map();

const getBillingDashboardCache = (userKey) => {
  if (!billingDashboardCacheByUser.has(userKey)) {
    billingDashboardCacheByUser.set(userKey, {
      summary: null,
      transactions: [],
      pendingPayment: null,
      loadedAt: 0,
    });
  }

  return billingDashboardCacheByUser.get(userKey);
};

export default function BillingDashboardPage({ user, setUser }) {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const reduceMotion = useReducedMotion();
  const billingCacheKey = String(
    user?._id || user?.id || user?.uid || user?.email || "anonymous",
  );
  const billingDashboardCache = getBillingDashboardCache(billingCacheKey);

  const [mobileOpen, setMobileOpen] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(
    () => localStorage.getItem("rio-sidebar-open") !== "false",
  );

  const [summary, setSummary] = useState(billingDashboardCache.summary);
  const [transactions, setTransactions] = useState(billingDashboardCache.transactions);
  const [pendingPayment, setPendingPayment] = useState(billingDashboardCache.pendingPayment);
  const [remainingSeconds, setRemainingSeconds] = useState(0);

  const [loading, setLoading] = useState(!billingDashboardCache.loadedAt);
  const [error, setError] = useState("");

  const [addBalanceOpen, setAddBalanceOpen] = useState(false);
  const [paymentLoading, setPaymentLoading] = useState(false);
  const [paymentError, setPaymentError] = useState("");
  const [cancelConfirmOpen, setCancelConfirmOpen] = useState(false);
  const continuePendingPaymentRef = useRef(null);

  // Open the Add Balance modal when another billing page navigates to
  // /billing?addBalance=1. Remove the one-shot query flag after consuming it.
  useEffect(() => {
    if (searchParams.get("addBalance") !== "1") return;

    setPaymentError("");
    setAddBalanceOpen(true);

    const nextParams = new URLSearchParams(searchParams);
    nextParams.delete("addBalance");
    setSearchParams(nextParams, { replace: true });
  }, [searchParams, setSearchParams]);

  // History can deep-link to the exact pending transaction to continue checkout.
  useEffect(() => {
    const requestedTransaction = searchParams.get("continuePayment");
    if (!requestedTransaction || !pendingPayment?.transactionId) return;
    if (requestedTransaction !== pendingPayment.transactionId || paymentLoading)
      return;

    const nextParams = new URLSearchParams(searchParams);
    nextParams.delete("continuePayment");
    setSearchParams(nextParams, { replace: true });
    continuePendingPaymentRef.current?.();
  }, [
    searchParams,
    setSearchParams,
    pendingPayment?.transactionId,
    paymentLoading,
  ]);

  const firstName = user?.name?.trim()?.split(/\s+/)?.[0] || "there";

  const loadBilling = useCallback(async ({ forceLoading = false } = {}) => {
    if (forceLoading || !billingDashboardCache.loadedAt) setLoading(true);
    setError("");

    try {
      const [summaryResult, transactionsResult, pendingResult] =
        await Promise.allSettled([
          getBillingSummary(),
          getBillingTransactions({ page: 1, pageSize: 5 }),
          getPendingBillingPayment(),
        ]);

      if (summaryResult.status === "fulfilled") {
        const nextSummary = unwrap(summaryResult.value);
        setSummary(nextSummary);
        billingDashboardCache.summary = nextSummary;
        const currentBalance =
          nextSummary?.balance ??
          nextSummary?.currentBalance ??
          nextSummary?.availableBalance;
        if (currentBalance != null && Number.isFinite(Number(currentBalance))) {
          setUser?.((current) => ({
            ...(current || {}),
            balance: Number(currentBalance),
          }));
          window.dispatchEvent(new Event("rio:balance-updated"));
        }
      }

      if (transactionsResult.status === "fulfilled") {
        const transactionList = getTransactionList(transactionsResult.value);
        setTransactions(transactionList);
        billingDashboardCache.transactions = transactionList;
      }

      // The dedicated endpoint is not limited by the five recent history rows.
      if (pendingResult.status === "fulfilled") {
        const pending = unwrap(pendingResult.value);
        const nextPending = pending && pending.transactionId ? pending : null;
        setPendingPayment(nextPending);
        billingDashboardCache.pendingPayment = nextPending;
      } else if (transactionsResult.status === "fulfilled") {
        const transactionList = getTransactionList(transactionsResult.value);
        const pending = transactionList.find((transaction) => {
          const status = getStatus(transaction);
          const expiresAt = transaction?.expiresAt
            ? new Date(transaction.expiresAt).getTime()
            : 0;
          return (
            transaction?.source === "billing" &&
            ["pending", "created", "processing"].includes(status) &&
            Number.isFinite(expiresAt) &&
            expiresAt > Date.now()
          );
        });
        setPendingPayment(pending || null);
        billingDashboardCache.pendingPayment = pending || null;
      }

      if (summaryResult.status === "fulfilled" || transactionsResult.status === "fulfilled" || pendingResult.status === "fulfilled") {
        billingDashboardCache.loadedAt = Date.now();
      }

      if (
        summaryResult.status === "rejected" &&
        transactionsResult.status === "rejected"
      ) {
        setError(
          summaryResult.reason?.response?.data?.message ||
            transactionsResult.reason?.response?.data?.message ||
            "We couldn't load your billing information.",
        );
      } else if (summaryResult.status === "rejected") {
        setError(
          summaryResult.reason?.response?.data?.message ||
            "Your billing summary couldn't be loaded.",
        );
      } else if (transactionsResult.status === "rejected") {
        setError(
          transactionsResult.reason?.response?.data?.message ||
            "Recent transactions couldn't be loaded.",
        );
      }
    } catch {
      setError("Something went wrong while loading billing data.");
    } finally {
      setLoading(false);
    }
  }, [setUser, billingDashboardCache]);

  const handleAddBalance = async (amount, existingOrder = null) => {
    if (paymentLoading) return;

    setPaymentLoading(true);
    setPaymentError("");

    try {
      const scriptLoaded = await loadRazorpayScript();

      if (!scriptLoaded) {
        throw new Error(
          "Razorpay Checkout could not be loaded. Please try again.",
        );
      }

      const orderResponse = existingOrder
        ? { success: true, data: existingOrder }
        : await createBillingOrder({ amount });
      const order = orderResponse?.data;

      if (
        orderResponse?.success !== true ||
        !order?.orderId ||
        !order?.keyId ||
        !Number.isSafeInteger(order?.amount) ||
        order.amount <= 0
      ) {
        throw new Error("The payment order response is invalid.");
      }

      await new Promise((resolve, reject) => {
        let paymentFinished = false;
        let checkout;

        const finish = (callback) => {
          if (paymentFinished) return;
          paymentFinished = true;
          callback();
        };

        checkout = new window.Razorpay({
          key: order.keyId,
          amount: order.amount,
          currency: order.currency || "INR",
          name: "RIO",
          description: `RIO balance top-up of ₹${(amount ?? order.amount / 100).toLocaleString("en-IN")}`,
          order_id: order.orderId,

          handler: async (paymentResponse) => {
            try {
              if (
                paymentResponse?.razorpay_order_id !== order.orderId ||
                !paymentResponse?.razorpay_payment_id ||
                !paymentResponse?.razorpay_signature
              ) {
                throw new Error(
                  "Razorpay returned incomplete payment details.",
                );
              }

              const verificationResponse = await verifyBillingPayment({
                orderId: paymentResponse.razorpay_order_id,
                paymentId: paymentResponse.razorpay_payment_id,
                signature: paymentResponse.razorpay_signature,
              });

              const verified = verificationResponse?.data;

              if (
                verificationResponse?.success !== true ||
                verified?.status !== "paid" ||
                verified?.balanceCreditStatus !== "completed"
              ) {
                throw new Error(
                  "Payment received, but balance credit is not confirmed. Please refresh billing before retrying.",
                );
              }

              finish(resolve);
            } catch (verificationError) {
              finish(() => reject(verificationError));
            }
          },

          modal: {
            ondismiss: async () => {
              try {
                if (order.transactionId) {
                  await cancelBillingPayment(order.transactionId);
                }
                await loadBilling();
                finish(resolve);
              } catch (dismissError) {
                // If Razorpay reports an unresolved attempt, keep the status visible
                // and let backend reconciliation decide; don't claim it was expired.
                await loadBilling();
                finish(() => reject(dismissError));
              }
            },
          },

          theme: {
            color: "#17191C",
          },
        });

        checkout.on("payment.failed", (event) => {
          finish(() =>
            reject(
              new Error(
                event?.error?.description ||
                  "Payment failed. Please try again.",
              ),
            ),
          );
        });

        checkout.open();
      });

      setAddBalanceOpen(false);
      await loadBilling();
    } catch (paymentError) {
      const message =
        paymentError?.response?.data?.message ||
        paymentError?.message ||
        "Unable to complete the payment. Please try again.";

      setPaymentError(message);
    } finally {
      setPaymentLoading(false);
    }
  };

  const handleContinuePendingPayment = async () => {
    if (!pendingPayment?.transactionId || paymentLoading) return;
    setPaymentError("");
    setPaymentLoading(true);
    try {
      const response = await continueBillingPayment(
        pendingPayment.transactionId,
      );
      const order = unwrap(response);
      if (
        !order?.orderId ||
        !order?.keyId ||
        !Number.isSafeInteger(order?.amount)
      ) {
        throw new Error("The existing payment order response is invalid.");
      }
      setPaymentLoading(false);
      await handleAddBalance(order.amount / 100, order);
    } catch (error) {
      setPaymentError(
        error?.response?.data?.message ||
          error?.message ||
          "Unable to continue this payment.",
      );
      setPaymentLoading(false);
      await loadBilling();
    }
  };

  continuePendingPaymentRef.current = handleContinuePendingPayment;

  const handleCancelPendingPayment = async () => {
    if (!pendingPayment?.transactionId || paymentLoading) return;
    setCancelConfirmOpen(false);
    setPaymentLoading(true);
    setPaymentError("");
    try {
      await cancelBillingPayment(pendingPayment.transactionId);
      await loadBilling();
    } catch (error) {
      setPaymentError(
        error?.response?.data?.message ||
          error?.message ||
          "Unable to cancel this payment.",
      );
      await loadBilling();
    } finally {
      setPaymentLoading(false);
    }
  };

  useEffect(() => {
    setSummary(billingDashboardCache.summary);
    setTransactions(billingDashboardCache.transactions);
    setPendingPayment(billingDashboardCache.pendingPayment);
    setLoading(!billingDashboardCache.loadedAt);

    if (!billingDashboardCache.loadedAt) {
      void loadBilling({ forceLoading: true });
    }
  }, [billingCacheKey, loadBilling, billingDashboardCache.loadedAt, billingDashboardCache.pendingPayment, billingDashboardCache.summary, billingDashboardCache.transactions]);

  useEffect(() => {
    if (!pendingPayment?.expiresAt) {
      setRemainingSeconds(0);
      return undefined;
    }

    let intervalId;

    const updateCountdown = () => {
      const expiresAt = new Date(pendingPayment.expiresAt).getTime();
      const seconds = Math.max(0, Math.ceil((expiresAt - Date.now()) / 1000));

      setRemainingSeconds(seconds);

      if (seconds === 0) {
        if (intervalId) window.clearInterval(intervalId);
        // First call reconciles the expired order through the backend endpoint.
        // The transaction-list request in that same call may have started before
        // reconciliation finished, so fetch once more to show the persisted status.
        void (async () => {
          await loadBilling();
          await loadBilling();
        })();
      }
    };

    updateCountdown();
    intervalId = window.setInterval(updateCountdown, 1000);

    return () => window.clearInterval(intervalId);
  }, [pendingPayment?.expiresAt, loadBilling]);

  const pendingCountdown = `${String(Math.floor(remainingSeconds / 60)).padStart(2, "0")}:${String(remainingSeconds % 60).padStart(2, "0")}`;

  const balance = useMemo(() => {
    const candidate =
      summary?.balance ??
      summary?.currentBalance ??
      summary?.availableBalance ??
      user?.balance;

    return candidate != null && Number.isFinite(Number(candidate))
      ? Number(candidate)
      : null;
  }, [summary, user?.balance]);

  const paidTransactions = useMemo(
    () =>
      transactions.filter((transaction) =>
        SUCCESS_STATUSES.has(getStatus(transaction)),
      ),
    [transactions],
  );

  // Prefer the backend's complete count over the current page's count.
  const successfulPayments =
    summary?.successfulPayments ??
    summary?.successfulTransactions ??
    summary?.paidCount ??
    paidTransactions.length;

  const totalAmount = summary?.totalTopUpAmount;

  const stats = [
    {
      label: "Available balance",
      value: balance === null ? "—" : formatCurrency(balance),
      detail: "Your current account balance",
      Icon: FiCreditCard,
    },
    {
      label: "Successful transactions",
      value: formatNumber(successfulPayments),
      detail: "Completed top-ups and balance activity",
      Icon: FiCheckCircle,
    },
    {
      label: "Total top-ups",
      value: formatInrFromPaise(totalAmount),
      detail: "Total amount added through successful payments",
      Icon: FiArrowUpRight,
    },
  ];

  return (
    <div className="relative min-h-screen overflow-x-clip bg-[#17191C] text-white">
      {/* Background */}
      <div aria-hidden="true" className="pointer-events-none fixed inset-0">
        <div
          className="absolute inset-0"
          style={{
            background:
              "radial-gradient(ellipse 70% 55% at 88% 4%, rgba(255,255,255,0.065) 0%, rgba(255,255,255,0.02) 42%, transparent 72%), radial-gradient(ellipse 65% 55% at 0% 92%, rgba(255,255,255,0.03) 0%, transparent 70%), linear-gradient(135deg, #191b1e 0%, #17191c 48%, #141619 100%)",
          }}
        />
      </div>

      {/* Shared mobile app bar */}
      <div className="relative z-10 flex min-h-screen">
        <ServiceNavigation
          user={user}
          setUser={setUser}
          mobileOpen={mobileOpen}
          setMobileOpen={setMobileOpen}
          sidebarOpen={sidebarOpen}
          setSidebarOpen={setSidebarOpen}
        />

        <main
          className={`min-w-0 flex-1 transition-[margin-left] duration-300 ease-out ${
            sidebarOpen ? "md:ml-[250px]" : "md:ml-[76px]"
          }`}
        >
          <div className="mx-auto w-full max-w-[1480px] px-5 pb-22 pt-[clamp(5.5rem,10vh,6.5rem)] sm:px-7 sm:pb-10 lg:px-10 lg:pb-12 lg:pt-10">
            {/* Page heading */}
            <motion.section
              initial={reduceMotion ? false : { opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, ease }}
              className="mb-9 flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between"
            >
              <div className="max-w-3xl">
                <PageEyebrow className="mb-4">Billing & account</PageEyebrow>

                <h1 className="text-[38px] font-semibold leading-[0.98] tracking-[-0.055em] sm:text-[50px] lg:text-[58px]">
                  Your balance,
                  <span className="mt-2 block font-serif font-normal italic tracking-[-0.055em] text-[#A1A1AA]">
                    clearly accounted for.
                  </span>
                </h1>

                <p className="mt-5 max-w-2xl text-[14px] leading-7 text-[#92949B] sm:text-[15px]">
                  Welcome back, {firstName}. Review your available balance and
                  keep track of your billing activity in one place.
                </p>
              </div>

              <div className="hidden items-center gap-3 sm:flex">
                <button
                  type="button"
                  onClick={() => navigate("/billing/history")}
                  className="group inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.035] px-4 py-3 text-xs font-semibold text-[#D4D4D8] transition duration-200 hover:border-white/[0.18] hover:bg-white/[0.065] hover:text-white focus:outline-none focus:ring-2 focus:ring-white/20 sm:px-5"
                >
                  <FiClock size={14} />
                  Transaction history
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setPaymentError("");
                    setAddBalanceOpen(true);
                  }}
                  className="group inline-flex items-center gap-2 rounded-full bg-white px-4 py-3 text-xs font-semibold text-[#17191C] shadow-[0_10px_30px_rgba(255,255,255,0.08)] transition duration-200 hover:-translate-y-0.5 hover:shadow-[0_14px_34px_rgba(255,255,255,0.12)] focus:outline-none focus:ring-2 focus:ring-white/30 sm:px-5"
                >
                  <FiPlus size={14} className={""} />
                  Add Balance
                </button>
              </div>
            </motion.section>

            {/* Error state */}
            {error && (
              <div
                role="alert"
                className="mb-5 flex items-start gap-3 rounded-2xl border border-white/10 bg-white/[0.035] p-4 text-sm text-[#D4D4D8]"
              >
                <FiAlertCircle
                  className="mt-0.5 shrink-0 text-[#A1A1AA]"
                  size={16}
                />

                <span className="min-w-0 flex-1 leading-6">{error}</span>

                <button
                  type="button"
                  onClick={() => void loadBilling({ forceLoading: true })}
                  className="shrink-0 text-xs font-semibold text-white underline underline-offset-4"
                >
                  Retry
                </button>
              </div>
            )}

            {/* Pending payment: display and server-based expiry countdown */}
            {pendingPayment && (
              <section className="mb-6 rounded-2xl border border-amber-400/25 bg-amber-400/[0.06] p-5">
                <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                  <div>
                    <p className="text-sm font-semibold text-amber-300">
                      Payment pending
                    </p>
                    <p className="mt-1 text-sm text-white/70">
                      Complete this payment before it expires.
                    </p>
                    <p className="mt-2 text-xs text-white/50">
                      Transaction: {pendingPayment.transactionId}
                    </p>
                    <button
                      type="button"
                      onClick={() =>
                        navigate(
                          `/billing/history?transaction=${encodeURIComponent(pendingPayment.transactionId)}`,
                        )
                      }
                      className="mt-2 text-xs font-semibold text-amber-200 underline underline-offset-4 hover:text-amber-100"
                    >
                      View this payment in History
                    </button>
                    {paymentError && (
                      <p
                        role="alert"
                        className="mt-2 max-w-xl text-xs text-rose-300"
                      >
                        {paymentError}
                      </p>
                    )}
                  </div>
                  <div className="flex flex-col gap-3 sm:items-end">
                    <div className="sm:text-right">
                      <p className="text-xs text-white/55">Time remaining</p>
                      <p className="mt-1 text-xl font-semibold tabular-nums text-white">
                        {pendingCountdown}
                      </p>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <button
                        type="button"
                        disabled={paymentLoading || remainingSeconds <= 0}
                        onClick={() => void handleContinuePendingPayment()}
                        className="rounded-lg bg-amber-300 px-4 py-2 text-xs font-semibold text-black transition hover:bg-amber-200 disabled:cursor-not-allowed disabled:opacity-50"
                      >
                        {paymentLoading ? "Please wait…" : "Continue Payment"}
                      </button>
                      <button
                        type="button"
                        disabled={paymentLoading}
                        onClick={() => setCancelConfirmOpen(true)}
                        className="rounded-lg border border-white/15 px-4 py-2 text-xs font-semibold text-white/80 transition hover:bg-white/[0.06] disabled:cursor-not-allowed disabled:opacity-50"
                      >
                        Cancel Payment
                      </button>
                    </div>
                  </div>
                </div>
              </section>
            )}

            {/* Billing overview */}
            <section aria-label="Billing overview" className="mb-9">
              <div className="grid gap-3 md:grid-cols-3">
                {stats.map((stat, index) => (
                  <BillingMetricCard
                    key={stat.label}
                    {...stat}
                    loading={loading}
                    index={index}
                    reduceMotion={reduceMotion}
                  />
                ))}
              </div>
            </section>

            {/* Recent transactions */}

            <section className="mb-10">
              <div className="mb-5 flex items-end justify-between gap-4">
                <div className="w-full text-center sm:w-auto sm:text-left">
                  <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-[#666870]">
                    Account activity
                  </p>

                  <h2 className="mt-2 text-[25px] font-semibold tracking-[-0.04em] sm:text-[29px]">
                    Recent transactions.
                  </h2>
                </div>
              </div>

              <Surface>
                {loading ? (
                  <div className="divide-y divide-white/[0.07] px-5 sm:px-7">
                    {[1, 2, 3].map((item) => (
                      <div key={item} className="flex items-center gap-4 py-5">
                        <div className="h-10 w-10 animate-pulse rounded-full bg-white/[0.06]" />

                        <div className="min-w-0 flex-1 space-y-2">
                          <div className="h-3 w-40 animate-pulse rounded bg-white/[0.07]" />
                          <div className="h-2.5 w-28 animate-pulse rounded bg-white/[0.04]" />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : transactions.length > 0 ? (
                  <div className="px-5 sm:px-7">
                    {transactions.map((transaction, index) => (
                      <div
                        key={
                          transaction?._id ||
                          transaction?.transactionId ||
                          `${transaction?.createdAt || "transaction"}-${index}`
                        }
                        className={`flex flex-col gap-3 py-5 sm:flex-row sm:items-center sm:justify-between ${
                          index ? "border-t border-white/[0.07]" : ""
                        }`}
                      >
                        <div className="flex min-w-0 items-start gap-3">
                          <span className="mt-0.5 flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-white/[0.08] bg-white/[0.035] text-[#92949B]">
                            <FiCreditCard size={16} />
                          </span>

                          <div className="min-w-0 flex-1">
                            <p className="truncate text-sm font-semibold text-[#D4D4D8]">
                              {transaction?.description ||
                                transaction?.resourceName ||
                                transaction?.serviceName ||
                                (transaction?.source === "balance" ||
                                transaction?.amountUnit === "balance-unit"
                                  ? String(
                                      transaction?.action ||
                                        "Balance deduction",
                                    )
                                      .replaceAll("-", " ")
                                      .replace(/^./, (character) =>
                                        character.toUpperCase(),
                                      )
                                  : transaction?.planName ||
                                    "Balance purchase")}
                            </p>

                            <p className="mt-1.5 text-[10px] text-[#777B85]">
                              {formatDate(
                                transaction?.createdAt ||
                                  transaction?.updatedAt,
                              )}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center justify-between gap-4 pl-[52px] sm:pl-0">
                          <TransactionStatusLabel
                            status={getStatus(transaction)}
                          />

                          <span className="text-sm font-semibold text-white">
                            {transaction?.source === "balance" ||
                            transaction?.amountUnit === "balance-unit" ? (
                              <span
                                className={
                                  transaction?.type === "deduction"
                                    ? "text-red-400"
                                    : "text-emerald-300"
                                }
                              >
                                {transaction?.type === "deduction" ? "−" : "+"}
                                {formatInrFromRupees(transaction?.amount)}
                              </span>
                            ) : (
                              formatInrFromPaise(
                                transaction?.amount ??
                                  transaction?.amountInPaise,
                              )
                            )}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="px-5 py-12 sm:px-7">
                    <div className="flex flex-col items-center gap-3 text-center sm:flex-row sm:items-start sm:gap-3 sm:text-left">
                      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-white/[0.08] bg-white/[0.025] text-[#858994]">
                        <FiCreditCard size={16} />
                      </span>

                      <div>
                        <h3 className="text-sm font-semibold text-[#D4D4D8]">
                          Your transactions will appear here.
                        </h3>

                        <p className="mx-auto mt-1 max-w-xl text-xs leading-5 text-[#777B85] sm:mx-0">
                          Once you have billing activity, you can review its
                          amount, date, and payment status here.
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </Surface>
            </section>

            {/* Billing footer */}

            <footer className="flex flex-col items-center gap-4 border-t border-white/[0.08] pt-7 text-center sm:flex-row sm:items-end sm:justify-between sm:text-left">
              <div className="w-full sm:w-auto">
                <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-[#666870]">
                  Billing overview
                </p>

                <h2 className="mt-2 text-xl font-semibold tracking-[-0.035em] sm:text-[23px]">
                  Your account, at a glance.
                </h2>

                <p className="mx-auto mt-2 max-w-xl text-xs leading-5 text-[#777B85] sm:mx-0">
                  Your available balance and recent payment activity are
                  displayed here.
                </p>
              </div>

              <button
                type="button"
                onClick={() => void loadBilling({ forceLoading: true })}
                disabled={loading}
                className="inline-flex items-center justify-center gap-2 self-center rounded-full bg-white px-5 py-3 text-xs font-semibold text-[#17191C] transition hover:-translate-y-0.5 hover:bg-[#E8E8EB] disabled:cursor-not-allowed disabled:opacity-50 sm:self-start"
              >
                <FiRefreshCw
                  size={14}
                  className={loading ? "animate-spin" : ""}
                />
                Refresh billing
                <FiArrowRight size={14} />
              </button>
            </footer>
          </div>
        </main>
      </div>

      {/* Mobile bottom actions */}
      <MobileActionBar className="sm:hidden">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => navigate("/billing/history")}
            className="group flex min-w-0 flex-1 items-center justify-center gap-2 rounded-full border border-white/10 bg-white/[0.035] px-3 py-3 text-xs font-semibold text-[#D4D4D8] transition duration-200 hover:border-white/[0.18] hover:bg-white/[0.065] hover:text-white focus:outline-none focus:ring-2 focus:ring-white/20"
          >
            <FiClock size={14} />
            <span>History</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setPaymentError("");
              setAddBalanceOpen(true);
            }}
            className="flex min-w-0 flex-1 items-center justify-center gap-2 rounded-full bg-white px-3 py-3 text-xs font-semibold text-[#17191C] shadow-[0_-10px_35px_rgba(0,0,0,0.22)] transition duration-200 hover:bg-[#E8E8EB] active:scale-[0.99] focus:outline-none focus:ring-2 focus:ring-white/30"
          >
            <FiPlus size={15} />
            <span>Add balance</span>
            <FiArrowRight size={14} />
          </button>
        </div>
      </MobileActionBar>
      {cancelConfirmOpen && (
        <div className="fixed inset-0 z-[120] flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm">
          <section
            role="alertdialog"
            aria-modal="true"
            aria-labelledby="cancel-payment-title"
            className="w-full max-w-md rounded-2xl border border-white/10 bg-[#151719] p-5 shadow-2xl sm:p-6"
          >
            <div className="flex items-start gap-3">
              <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-amber-300/20 bg-amber-300/[.08] text-amber-200">
                <FiAlertCircle size={19} />
              </span>
              <div className="min-w-0">
                <h2
                  id="cancel-payment-title"
                  className="text-base font-semibold text-white"
                >
                  Cancel this payment?
                </h2>
                <p className="mt-2 text-sm leading-6 text-[#A1A1AA]">
                  This checkout will be closed. If Razorpay has already captured
                  or is still processing the payment, we will keep the
                  transaction safe and reconcile its status.
                </p>
                {pendingPayment?.transactionId && (
                  <p className="mt-3 break-all font-mono text-[11px] text-[#777B85]">
                    Reference: {pendingPayment.transactionId}
                  </p>
                )}
              </div>
            </div>
            {paymentError && (
              <p role="alert" className="mt-3 text-xs text-rose-300">
                {paymentError}
              </p>
            )}
            <div className="mt-6 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setCancelConfirmOpen(false)}
                disabled={paymentLoading}
                className="rounded-xl border border-white/10 px-4 py-2.5 text-xs font-semibold text-[#D4D4D8] hover:bg-white/[.05] disabled:opacity-50"
              >
                Keep payment
              </button>
              <button
                type="button"
                onClick={() => void handleCancelPendingPayment()}
                disabled={paymentLoading}
                className="rounded-xl bg-amber-300 px-4 py-2.5 text-xs font-semibold text-black hover:bg-amber-200 disabled:opacity-50"
              >
                {paymentLoading ? "Cancelling…" : "Yes, cancel payment"}
              </button>
            </div>
          </section>
        </div>
      )}
      {addBalanceOpen && (
        <AddBalanceModal
          onClose={() => {
            if (paymentLoading) return;
            setAddBalanceOpen(false);
            setPaymentError("");
          }}
          onContinue={handleAddBalance}
          currentBalance={balance}
          loading={paymentLoading}
          error={paymentError}
        />
      )}
    </div>
  );
}
