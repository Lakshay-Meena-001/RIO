import api from "../../utils/axios";

/*
 * Start a new mock interview.
 *
 * All interview questions are generated together
 * when the interview starts.
 *
 * POST /api/interview/start
 */
export const startInterview = async (interviewData) => {
  const response = await api.post("/api/interview/start", interviewData);

  return response.data;
};

/*
 * Get the authenticated user's active interview, if one exists.
 *
 * GET /api/interview/active
 */
export const getActiveInterview = async ({ fresh = false } = {}) => {
  const response = await api.get("/api/interview/active", {
    ...(fresh ? { skipCache: true } : { cacheTTL: 5 * 60 * 1000 }),
  });

  return response.data;
};

/*
 * Begin an interview after the user accepts the rules.
 *
 * This is when the actual interview timer starts.
 *
 * POST /api/interview/:interviewId/begin
 */
export const beginInterview = async (interviewId) => {
  const response = await api.post(`/api/interview/${interviewId}/begin`);

  return response.data;
};

/*
 * Move to the next question.
 *
 * This is navigation only.
 * It does NOT generate a new question.
 *
 * POST /api/interview/:interviewId/next
 */
export const getNextQuestion = async (interviewId) => {
  const response = await api.post(`/api/interview/${interviewId}/next`);

  return response.data;
};

/*
 * Move to the previous question.
 *
 * This is navigation only.
 *
 * POST /api/interview/:interviewId/previous
 */
export const getPreviousQuestion = async (interviewId) => {
  const response = await api.post(`/api/interview/${interviewId}/previous`);

  return response.data;
};

/*
 * Jump to question.
 *
 * This is navigation only.
 *
 * POST /api/interview/:interviewId/jump
 */

export const jumpToQuestion = async (interviewId, index) => {
  const response = await api.post(`/api/interview/${interviewId}/jump`, {
    index,
  });

  return response.data;
};

/*
 * Save the current answer as a draft.
 *
 * This does NOT submit or evaluate the answer.
 *
 * PATCH /api/interview/:interviewId/draft
 */
export const saveDraftAnswer = async (
  interviewId,
  questionId,
  answer,
  signal,
) => {
  const response = await api.patch(
    `/api/interview/${interviewId}/draft`,
    {
      questionId,
      answer,
    },
    {
      signal,
    },
  );

  return response.data;
};

/*
 * Submit the complete interview.
 *
 * The backend evaluates all remaining unsubmitted
 * questions and generates the final interview report.
 *
 * Already submitted questions are not re-evaluated.
 *
 * POST /api/interview/:interviewId/submit
 */
export const submitInterview = async (interviewId, draftAnswers = {}) => {
  const response = await api.post(`/api/interview/${interviewId}/submit`, {
    draftAnswers,
  });

  return response.data;
};

/*
 * Get one complete interview attempt.
 *
 * GET /api/interview/:interviewId
 */
export const getInterview = async (interviewId) => {
  const response = await api.get(`/api/interview/${interviewId}`);

  return response.data;
};

export const replaceActiveInterview = async () => {
  const response = await api.post("/api/interview/active/replace");
  return response.data;
};

/*
 * Get the authenticated user's interview history.
 *
 * GET /api/interview/history
 */
export const getInterviewHistory = async () => {
  const response = await api.get("/api/interview/history");

  return response.data;
};

/*
 * Quit the current interview.
 *
 * PATCH /api/interview/:interviewId/quit
 */
export const quitInterview = async (interviewId) => {
  const response = await api.patch(`/api/interview/${interviewId}/quit`);

  return response.data;
};

/*
 * Delete one interview attempt.
 *
 * DELETE /api/interview/:interviewId
 */
export const deleteInterview = async (interviewId) => {
  const response = await api.delete(`/api/interview/${interviewId}`);

  return response.data;
};

export const getRecentlyTerminatedInterview = async () => {
  const response = await api.get("/api/interview/recently-terminated");
  return response.data;
};

export const dismissTerminationNotice = async (interviewId) => {
  const response = await api.patch(
    `/api/interview/${interviewId}/termination-notice/dismiss`,
  );

  return response.data;
};
